/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Services;

import Reponsitory.KhachHangRepo;
import entity.KhachHang;

/**
 *
 * @author Phan_Triu
 */
public class KhachHangService {
    KhachHangRepo khachHangRepo = new KhachHangRepo();
    
   public String addNew(KhachHang khachHang){
       if(khachHangRepo.addNew(khachHang) == true){
           return "Them thanh cong";
       }else{
           return "Them that bai";
       }
   } 
}
