/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.KhachHang;

/**
 *
 * @author Phan_Triu
 */
public class KhachHangService {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;
    public ArrayList<KhachHang> getAllKH() {
        sql = "SELECT * FROM KhachHang";
        ArrayList<KhachHang> listKH = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
           while (rs.next()) {
                KhachHang kh = new KhachHang(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                listKH.add(kh);
           }
                return listKH;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public int themKH(KhachHang kh) {
        sql = "INSERT INTO [dbo].[KhachHang] ([ten],[sdt],[email],[diaChi]) VALUES (???)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);

            ps.setObject(1, kh.getTenKH());
            ps.setObject(2, kh.getSdt());
            ps.setObject(3, kh.getEmail());
            ps.setObject(4, kh.getDiaChi());
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    public int deleteKH(String id) {
        sql = "DELETE FROM KhachHang WHERE id = ?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);

            ps.setObject(1, id);

            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
}

