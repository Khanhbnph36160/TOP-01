/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Reponsitory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import entity.KhachHang;

/**
 *
 * @author Phan_Triu
 */
public class KhachHangRepo {
    DBConnect dbconnect;
    
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String sql = null;
    public ArrayList<KhachHang> getAllKH() {
        sql = "SELECT * FROM KhachHang";
        ArrayList<KhachHang> listKH = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
           while (rs.next()) {
                KhachHang kh = new KhachHang(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
                listKH.add(kh);
           }
                return listKH;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
//    public int themKH(KhachHang kh) {
//        Integer row = null;
//        sql = "INSERT INTO [dbo].[KhachHang] ([ten],[sdt],[email],[diaChi]) VALUES (?,?,?,?)";
//        Connection cn = DBConnect.getConnection();
//        try {
//            PreparedStatement pstm = cn.prepareStatement(sql);
//            
//            pstm.setString(1, kh.getTenKH());
//            pstm.setString(2, kh.getSdt());
//            pstm.setString(3, kh.getEmail());
//            pstm.setString(4, kh.getDiaChi());
//            row = pstm.executeUpdate();
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//        return row;
//    }
    
    public Boolean addNew(KhachHang khachHang){
        String sql = "INSERT INTO [dbo].[KhachHang] ([ten],[sdt],[email],[diaChi]) VALUES (?,?,?,?)";
        
        try (Connection conn = dbconnect.getConnection();
                PreparedStatement pst = conn.prepareCall(sql);
                ){
            pst.setObject(1, khachHang.getTenKH());
            pst.setObject(2, khachHang.getSdt());
            pst.setObject(3, khachHang.getEmail());
            pst.setObject(4, khachHang.getDiaChi());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public int deleteKH(String id) {
        sql = "DELETE FROM KhachHang WHERE id = ?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);

            ps.setObject(1, id);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
}

